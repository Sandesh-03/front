export interface PortfolioItem {
    imageUrl: string;    // URL of the portfolio item image
    detailsLink: string; // Link to the detailed page
  }
  