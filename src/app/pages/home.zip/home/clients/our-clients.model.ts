export interface Client {
  logoUrl: string;
}
