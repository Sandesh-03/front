export interface FeatureItem {
    icon: string;         // Icon class name
    title: string;        // Title of the feature
    description: string;  // Description of the feature
  }  