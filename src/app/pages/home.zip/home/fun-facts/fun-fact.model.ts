export interface FunFact {
  icon: string; // Icon class name
  value: number; // Numeric value
  label: string; // Label for the fun fact
}
